import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/storage";

const firebaseConfig = {
    apiKey: "AIzaSyCxyAA4Dh3vK-d39D1FH6qJrV_fSG3MVwc",
    authDomain: "linkedin-clone-2e88b.firebaseapp.com",
    projectId: "linkedin-clone-2e88b",
    storageBucket: "linkedin-clone-2e88b.appspot.com",
    messagingSenderId: "506134624173",
    appId: "1:506134624173:web:b1ee125467d17e40b0d324"
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
const db = firebaseApp.firestore(); /*connect to db */
const auth = firebase.auth(); /*authentication */
const provider = new firebase.auth.GoogleAuthProvider();
const storage = firebase.storage(); /*store images */

export {auth, provider, storage, firebaseApp, db};