import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './components/Login';
import Header from './components/Header';
import Home from './components/Home';
import { useEffect } from 'react';
import { getUserAuth } from './actions';
import { connect } from 'react-redux';

function App(props) {

  useEffect(() => {
    props.getUserAuth();
  }, []);


  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element = {<Login></Login>}></Route>
          <Route path = "/home" element = {<HeaderandHome/>}></Route>
        </Routes>
      </Router>
    </div>
  );
}

function HeaderandHome(){
  return(
    <>
      <Header></Header>
      <Home></Home>
    </>
  );
}

/*map state and dispatch are used when not using redux toolkit*/
const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => ({
  getUserAuth: () => dispatch(getUserAuth()), /*getUserAuth function kind of defined here and called */
});

export default connect(mapStateToProps, mapDispatchToProps)(App);
