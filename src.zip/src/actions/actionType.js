export const SET_USER = 'SET_USER';
export const SET_LOADING_STATUS = 'SET_LOADING_STATUS';
export const GET_ARTICLES = 'GET_ARTICLES';