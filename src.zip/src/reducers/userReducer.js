import { SET_USER } from "../actions/actionType";


const INITIAL_STATE = {
    user: null,
};

const userReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) { /*when like button clicked, +1 */
            case SET_USER:
                return {  /*creating a new state when a new user comes in. This is cause Redux is immutable*/
                    ...state, 
                    user: action.user,
                };
        default:
            return state;
    }
};

export default userReducer;

//userReducer is basically a state updater